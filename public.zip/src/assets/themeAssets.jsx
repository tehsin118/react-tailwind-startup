const ThemeAssets = {
  eyeOpen: "src/assets/icons/eye-open.svg",
  eyeClose: "src/assets/icons/eye-close.svg",
};

export default ThemeAssets;
