import React from "react";

const YourCard = () => {
  return <div></div>;
};

export default YourCard;
