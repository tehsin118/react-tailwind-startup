import React from "react";

const Forget = () => {
  return <></>;
};

export default Forget;
