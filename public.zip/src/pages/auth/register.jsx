import React from "react";

const Register = () => {
  return <></>;
};

export default Register;
